from typing import Any, Dict
from .audit import record
from .fusion import context_mapping, fusion_test
from .pii import TokenVault, protect_payload

class PrivAgent:
    def __init__(self):
        self.vault = TokenVault()

    def inspect(self, user_task: str, tool: str, payload: Dict[str, Any], contexts: Dict[str, Dict[str, Any]]):
        protected_payload, detected_pii = protect_payload(payload, self.vault)
        mapping = context_mapping(payload, contexts)
        fusion = fusion_test(payload, contexts)

        evidence = [fusion["reason"]]
        if detected_pii:
            evidence.append(f"Detected PII types: {', '.join(sorted(detected_pii))}.")

        if fusion["risk"] == "HIGH":
            decision = "BLOCK"
        elif fusion["risk"] == "MEDIUM":
            decision = "REVIEW"
        else:
            decision = "ALLOW"

        executed = decision == "ALLOW"
        result = {"status": "executed", "tool": tool, "message": "Protected request accepted by simulated tool."} if executed else None
        record({
            "tool": tool,
            "decision": decision,
            "risk": fusion["risk"],
            "detected_pii": detected_pii,
            "evidence": evidence,
        })
        return {
            "decision": decision,
            "risk": fusion["risk"],
            "detected_pii": detected_pii,
            "protected_payload": protected_payload,
            "context_mapping": mapping,
            "fusion_analysis": fusion,
            "evidence": evidence,
            "tool_executed": executed,
            "tool_result": result,
        }
