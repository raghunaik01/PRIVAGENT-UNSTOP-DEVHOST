from datetime import datetime, timezone

AUDIT_LOG: list[dict] = []


def record(event: dict) -> dict:
    item = {"timestamp": datetime.now(timezone.utc).isoformat(), **event}
    AUDIT_LOG.append(item)
    return item
