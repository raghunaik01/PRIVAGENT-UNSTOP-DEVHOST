from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

class CheckRequest(BaseModel):
    user_task: str
    tool: str
    payload: Dict[str, Any]
    contexts: Dict[str, Dict[str, Any]] = Field(default_factory=dict)

class CheckResponse(BaseModel):
    decision: str
    risk: str
    detected_pii: Dict[str, list[str]]
    protected_payload: Dict[str, Any]
    context_mapping: Dict[str, Any]
    fusion_analysis: Dict[str, Any]
    evidence: list[str]
    tool_executed: bool
    tool_result: Optional[Dict[str, Any]] = None
