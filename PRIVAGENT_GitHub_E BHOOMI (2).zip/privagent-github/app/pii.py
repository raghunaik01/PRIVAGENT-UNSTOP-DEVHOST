import re
import secrets
from typing import Any, Dict, Tuple

EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
PHONE = re.compile(r"(?<!\d)(?:\+91[- ]?)?[6-9]\d{9}(?!\d)")
AADHAAR = re.compile(r"(?<!\d)\d{4}[- ]?\d{4}[- ]?\d{4}(?!\d)")

class TokenVault:
    def __init__(self):
        self._tokens: dict[str, str] = {}
        self._reverse: dict[str, str] = {}

    def token_for(self, value: str, kind: str) -> str:
        if value in self._reverse:
            return self._reverse[value]
        token = f"<{kind}_{secrets.token_hex(4).upper()}>"
        self._tokens[token] = value
        self._reverse[value] = token
        return token

    def restore(self, value: str) -> str:
        return self._tokens.get(value, value)


def protect_text(text: str, vault: TokenVault) -> Tuple[str, Dict[str, list[str]]]:
    found: Dict[str, list[str]] = {"EMAIL": [], "PHONE": [], "AADHAAR": []}

    def replace(pattern, kind, label, value):
        found[label].append(value)
        return vault.token_for(value, kind)

    text = EMAIL.sub(lambda m: replace(EMAIL, "EMAIL", "EMAIL", m.group()), text)
    text = PHONE.sub(lambda m: replace(PHONE, "PHONE", "PHONE", m.group()), text)
    text = AADHAAR.sub(lambda m: replace(AADHAAR, "AADHAAR", "AADHAAR", m.group()), text)
    return text, {k: v for k, v in found.items() if v}


def protect_payload(payload: Any, vault: TokenVault):
    all_found: Dict[str, list[str]] = {}
    if isinstance(payload, dict):
        out = {}
        for k, v in payload.items():
            protected, found = protect_payload(v, vault)
            out[k] = protected
            for kind, values in found.items():
                all_found.setdefault(kind, []).extend(values)
        return out, all_found
    if isinstance(payload, list):
        out = []
        for item in payload:
            protected, found = protect_payload(item, vault)
            out.append(protected)
            for kind, values in found.items():
                all_found.setdefault(kind, []).extend(values)
        return out, all_found
    if isinstance(payload, str):
        return protect_text(payload, vault)
    return payload, {}
