from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from .middleware import PrivAgent
from .models import CheckRequest, CheckResponse
from .audit import AUDIT_LOG

app = FastAPI(title="PRIVAGENT", version="1.0.0")
engine = PrivAgent()
ROOT = Path(__file__).resolve().parent.parent

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "project": "PRIVAGENT"}

@app.post("/api/check", response_model=CheckResponse)
def check(req: CheckRequest):
    return engine.inspect(req.user_task, req.tool, req.payload, req.contexts)

@app.get("/api/audit")
def audit():
    return {"events": AUDIT_LOG[-50:]}
