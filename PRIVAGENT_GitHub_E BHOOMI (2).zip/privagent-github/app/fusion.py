from typing import Any, Dict

SENSITIVE_KEYS = {
    "aadhaar", "aadhar", "ssn", "salary", "employee_id", "employeeid",
    "employee_benefits", "medical_record", "medical_records", "bank_account"
}

TRAVEL_KEYS = {"destination", "dates", "check_in", "check_out", "hotel", "room_type"}


def context_mapping(payload: Dict[str, Any], contexts: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    mapping = {}
    for name, ctx in contexts.items():
        fields = ctx.get("fields", [])
        mapping[name] = {
            "name": ctx.get("name", name),
            "fields_present": [f for f in fields if f in payload],
        }
    return mapping


def fusion_test(payload: Dict[str, Any], contexts: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    keys = {str(k).lower() for k in payload}
    sensitive = sorted(keys & SENSITIVE_KEYS)
    travel = sorted(keys & TRAVEL_KEYS)
    has_multiple_contexts = len(contexts) >= 2
    creates_cross_context_action = bool(sensitive and travel and has_multiple_contexts)

    if creates_cross_context_action:
        risk = "HIGH"
        reason = "The requested tool call combines travel data with employee/HR-sensitive context."
    elif sensitive:
        risk = "MEDIUM"
        reason = "Sensitive business data is present in the tool payload."
    else:
        risk = "LOW"
        reason = "No high-risk cross-context combination was detected."

    return {
        "context_A": contexts.get("A", {}),
        "context_B": contexts.get("B", {}),
        "tested": ["A", "B", "A+B"] if has_multiple_contexts else ["payload"],
        "cross_context_fusion": creates_cross_context_action,
        "risk": risk,
        "reason": reason,
    }
