from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    r = client.get('/api/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'


def test_high_risk_cross_context_request_is_blocked_and_pii_tokenized():
    body = {
        'user_task': 'Book a hotel in Delhi from 12-15 Nov',
        'tool': 'hotel_booking',
        'payload': {
            'destination': 'Delhi',
            'dates': '12-15 Nov',
            'employee_id': 'EMP1234',
            'email': 'demo@example.com',
            'phone': '9876543210',
            'aadhaar': '1234-5678-9012'
        },
        'contexts': {
            'A': {'name': 'Travel', 'fields': ['destination', 'dates']},
            'B': {'name': 'Employee/HR', 'fields': ['employee_id']}
        }
    }
    r = client.post('/api/check', json=body)
    assert r.status_code == 200
    data = r.json()
    assert data['decision'] == 'BLOCK'
    assert data['tool_executed'] is False
    assert 'EMAIL' in data['detected_pii']
    assert data['protected_payload']['email'].startswith('<EMAIL_')
    assert data['fusion_analysis']['cross_context_fusion'] is True


def test_low_risk_request_is_allowed():
    body = {
        'user_task': 'Find a hotel in Delhi',
        'tool': 'hotel_search',
        'payload': {'destination': 'Delhi', 'dates': '12-15 Nov'},
        'contexts': {'A': {'name': 'Travel', 'fields': ['destination', 'dates']}}
    }
    r = client.post('/api/check', json=body)
    assert r.status_code == 200
    data = r.json()
    assert data['decision'] == 'ALLOW'
    assert data['tool_executed'] is True
